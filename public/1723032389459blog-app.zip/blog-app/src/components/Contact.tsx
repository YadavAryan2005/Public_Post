import React from 'react'
import  contact from "../images/contact.png";
import Image from 'next/image';
function Contact() {
  return (
    <div className=' bg-[#0d0c22] flex flex-col justify-center items-center sm:min-h-[500px]'>
        <div className='p-5 lg:p-0 sm:flex md:min-h-[600px]  max-w-7xl mx-auto w-full justify-center items-center'>
        <div className='sm:w-1/2 '>
       <Image src={contact} width={500} alt='contact img'/>
      </div>
      <form className='sm:w-1/2 text-serif text-white flex flex-col gap-5'>
      <input className='p-2 rounded-md outline-none text-black font' type="text" name="" id="" placeholder='Name and Sername' />
      <input className='p-2 rounded-md outline-none text-black font' type="email" name="" id="" placeholder='Email Address' />
      <input className='p-2 rounded-md outline-none text-black font' type="number" name="" id="" placeholder='Enter Number' />
      <textarea rows={4} className='p-2 rounded-md outline-none text-black font' name="" id="" placeholder=' Message'></textarea>
      <input className='cursor-pointer p-2 rounded-md bg-blue-500' type="submit" value="Send" />
      </form>
      </div>
    </div>
  )
}

export default Contact
