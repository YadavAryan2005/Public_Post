import React from 'react'
import Image from 'next/image'
import hero from "../images/hero.gif";
import brand from "../images/brands.png"
function Homepage() {
  return (
    <div className=' bg-[#0d0c22] flex justify-center items-center sm:min-h-[500px]'>
        <div className='p-5 lg:p-0 sm:flex md:min-h-[600px]  max-w-7xl mx-auto justify-center items-center'>
      <div className='sm:w-1/2 text-serif text-white flex flex-col gap-5'>
        <h1 className='text-4xl md:text-6xl lg:text-7xl top-0 flex flex-wrap gap-3  md:flex-col'><p>Creative</p><p> Thoughts</p><p> Agency</p></h1>
        <p className='text-sm font-thin text-[#fbfbfbc4]'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus vel, adipisci iusto incidunt tenetur doloremque alias perferendis amet, vero rerum temporibus dolores explicabo cumque aspernatur.</p>
         <div className='font-bold'>
            <button className='text-black bg-white rounded-md p-2'>Learn More</button>&nbsp;&nbsp;
            <button className='text-black bg-gray-300 rounded-md p-2'>Contact</button>
         </div>
         <Image src={brand} alt='homepage' className='bottom-0'/>
      </div>
      <div className='sm:w-1/2 flex justify-end'>
       <Image src={hero} alt='homepage'/>
      </div>
      </div>
    </div>
  )
}

export default Homepage
