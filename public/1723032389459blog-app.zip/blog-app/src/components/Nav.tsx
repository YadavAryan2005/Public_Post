"use client";
import { link } from "fs";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
const navLinks = [
  { name: "Home", link: "/" },
  { name: "About", link: "/about" },
  { name: "Contact", link: "/contact" },
  { name: "Blog", link: "/blog" },
  { name: "Logout", link: "/logout" },
];
function Nav() {
  const [Open, isOpen] = useState(false);
  const pathname = usePathname();
  return (
    <>
    <header className="w-full text-white bg-black p-7">
      <div className="flex justify-between max-w-7xl mx-auto">
        <h1>Aryan</h1>
        <ul className="gap-4 hidden sm:flex">
          {navLinks.map((Links) => {
            return (
              <Link
                href={Links.link}
                key={Links.name}
                className={`${
                  pathname == Links.link ? "bg-white text-black" : "bg-black"
                } rounded-full px-5`}
              >
                <li>{Links.name}</li>
              </Link>
            );
          })}
        </ul>
        {Open?<div onClick={() => isOpen((prev=>!prev))} className="sm:hidden cursor-pointer font-bold flex w-5">X</div>:<div className="sm:hidden flex-col md:hidden">
          <div
            className="cursor-pointer w-8 flex flex-col gap-1 "
            onClick={() => isOpen((prev=>!prev))}
          >
            <hr className="border-2" />
            <hr className="border-2" />
            <hr className="border-2" />
          </div>
        </div>}
      </div>
    </header>
     {Open && (
      <ul className="sm:hidden p-5 absolute w-full flex flex-col justify-center items-center bg-slate-500 gap-1 text-white">
        {navLinks.map((Links) => {
          return (
            <Link 
              href={Links.link}
              key={Links.name}
              className={`${
                pathname == Links.link
                  && "bg-white text-black w-full text-center"
              } rounded-md px-5 py-3`}
            >
              <li className="w-full">{Links.name}</li>
            </Link>
          );
        })}
      </ul>
    )}
    </>
  );
}

export default Nav;
