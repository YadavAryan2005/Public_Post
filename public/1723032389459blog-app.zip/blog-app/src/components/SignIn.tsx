import { auth, signIn } from "@/auth";
import {login} from "../../utils/User";
export async  function SignIn() {
  async function show(){
  const data =await auth();
  console.log(data);
  login(data);
  }
  async function authonticate() {
    "use server";
    await signIn("github"); 
    show();
  }

  return (
    <>
      <form action={authonticate}>
        <button type="submit">Signin with GitHub</button>
      </form>
      <form
        action={async () => {
          "use server";
          const data: any = await signIn("google");
          console.log(await data.json());
        }}
      >
        <button type="submit">Signin with Google</button>
      </form>
    </>
  );
}
