import React from 'react'
import Image from 'next/image'
import about from "../images/about.png";
function About() {
  return (
    <div className='  bg-[#0d0c22] flex justify-center items-center sm:min-h-[500px]'>
        <div className='p-5 lg:p-0 sm:flex md:min-h-[600px]  max-w-7xl mx-auto justify-center items-center'>
      <div className='sm:w-1/2 text-serif text-white flex flex-col gap-5'>
      <h1>About Agency</h1>
        <h1 className='text-3xl md:text-4xl lg:5xl top-0'>We create digital ideas that are bigger,bolder braver and better.</h1>
         <div className='flex flex-wrap gap-5 text-xs'>
           <span>
            <h1 className='text-blue-500 text-3xl'>10 K+</h1>
            <p>Year of Experience</p>
           </span>
           <span>
            <h1 className='text-blue-500 text-3xl'>234 K+</h1>
            <p>Project Reached</p>
           </span>
           <span>
            <h1 className='text-blue-500 text-3xl'>5 K+</h1>
            <p>Services and plugins</p>
           </span>
         </div>
      </div>
      <div className='sm:w-1/2 flex justify-end'>
       <Image src={about} width={500} alt='homepage'/>
      </div>
      </div>
    </div>
  )
}

export default About
