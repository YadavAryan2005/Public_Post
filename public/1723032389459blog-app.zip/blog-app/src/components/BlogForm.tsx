import React from 'react'
import Image from 'next/image'
import Link from 'next/link';
import about from "../images/about.png";
function BlogForm() {
  return (
    <div className='text-white flex gap-4 flex-col rounded-2xl border p-5'>
      <Image src={about} alt=''/>
      <h1>this blog for information</h1>
      <Link href="/" className='text-center bg-blue-500 p-1 text-black rounded-md'>show more</Link>
    </div>
  )
}

export default BlogForm
