import Contact from '@/components/Contact'
import React from 'react'

function ContactPage() {
  return (
    <div className="bg-[#0d0c22] px-2">
      <Contact/>
    </div>
  )
}

export default ContactPage
