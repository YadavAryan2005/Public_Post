import Homepage from "@/components/Homepage";

export default function Home() {
  return (
    <main className="bg-[#0d0c22] px-2">
      <Homepage/>
    </main>
  );
}
