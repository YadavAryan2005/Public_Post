import { SignIn } from '@/components/SignIn'
import React from 'react'

function Login() {
  return (
    <div>
      <SignIn/>
    </div>
  )
}

export default Login
