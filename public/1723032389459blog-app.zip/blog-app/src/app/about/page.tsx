import About from '@/components/About'
import React from 'react'

function about() {
  return (
    <div className="bg-[#0d0c22] px-2">
      <About/>
    </div>
  )
}

export default about
