import BlogForm from "@/components/BlogForm";
import React from "react";

function Blog() {
  return (
    <div className=" bg-[#0d0c22] flex flex-col justify-center items-center sm:min-h-[500px]">
      <div className="p-5 lg:p-0 sm:flex md:min-h-[600px]  max-w-7xl mx-auto w-full justify-center items-center">
        <div className="bg-[#0d0c22] px-2 grid  grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          <BlogForm />
          <BlogForm />
          <BlogForm />
          <BlogForm />
          <BlogForm />
          <BlogForm />
          <BlogForm />
          <BlogForm />
          <BlogForm />
          <BlogForm />
          <BlogForm />
        </div>
      </div>
    </div>
  );
}

export default Blog;
