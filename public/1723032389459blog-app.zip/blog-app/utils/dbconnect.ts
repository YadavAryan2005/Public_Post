import mongoose from "mongoose";
const Dbconnect=async()=>{
    try {
        await mongoose.connect(process.env.MONGODB_STRING as string);
        console.log("database connected")
    } catch (error) {
        console.log("error in db connection",(error as Error).message);
        process.exit(1);
    }
}
export default Dbconnect;