import dbconnect from "./dbconnect";
import User from "../model/User";
import { auth } from "../src/auth";
import { Session } from "next-auth";
export const login=async(userData:Session | null)=>{
    try {
        dbconnect();
        const client=await User.findOne({email:userData.user.email});
        if(!client)
        {
            const client=new User({
                name:userData.user.name,
                email:userData.user.email,
                image:userData.user.image
            });
            await client.save();
        }
    } catch (error) {
        console.log(error);
    }
}